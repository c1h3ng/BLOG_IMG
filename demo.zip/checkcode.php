<?php
//require("../inc/config.inc.php");
require_once __DIR__ . "/vendor/autoload.php";
$conn = new MongoDB\Client();
$db = $conn->selectDatabase('ctf');
$collection = $db->selectCollection('user');
//$document = $collection->find([],[]);
var_dump($document);

session_start();
$_SESSION['is_admin'] = false;
$username = $_POST['username'];
$password = $_POST['password'];
$vertify = strtolower($_POST['vertify']);
if($username == "" or $password == ""){
	die("<script>alert('用户名和密码不能为空');location.href='index.php';</script>");
}
else if($vertify == ""){
	die("<script>alert('验证码不能为空');location.href='index.php';</script>");
}
else if($vertify != $_SESSION['vertify']){
	die("<script>alert('验证码不正确');location.href='index.php';</script>");
}
else{
	//$username = addslashes($username);
	//$password = md5(addslashes($password));
	//$sql = "select * from blog_admin where username='".$username."' and password='".$password."'";
	//$result = mysqli_query($conn,$sql) or die("something wrong");
	if(!mysqli_num_rows($result)){
		echo "<script>alert('用户名或密码错误');location.href='index.php';</script>";
	}
	else{
		$_SESSION['is_admin'] = true;
		echo "<script>alert('登陆成功');location.href='index.php';</script>";
	}

}
?>
